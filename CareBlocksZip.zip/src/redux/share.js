
export const Images = (state ={
    image1:'/assets/Blockchain.gif',
    image2:'/assets/detective.jpg',
    medical:'/assets/health.jpg',
    house:'/assets/house.jpg',
    orphanage:'/assets/orphanage.png',
    farm:'/assets/farm.jpg'
}) =>{
    return state;
}

