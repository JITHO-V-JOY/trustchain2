import React, {Component} from 'react';

class Home extends Component{
    constructor(props){
        super(props);
        this.state={

        }
    }
    render(){
        return(
            <div class="container"> 
                <div class="row">
                <div className="col-12 col-md mt-1 ">
                       <img src={this.props.images.image1} className="img-fluid" ></img>
        
                    </div>
                    <div className="col-12 col-md mt-5 ">
                        <h3>
                            CMDRF using Blockchain !
                        </h3>
                        <p>Distributed ledger of CMDRF- Chief Minister's Disaster Relief Fund System.</p>
                    </div>
                </div>

                <div class="row">

                <div className="col-12 col-md mt-5 ">
                <h3>
                    Transparent And Genuine
                </h3>
                <p>Maintains the system without corruption<br/> No money overflow.</p>
                <p></p>
                </div>

                <div className="col-12 col-md mt-1 ">
                       <img src={this.props.images.image2} class="img-fluid" ></img>
        
                    </div>
                   
                </div>
            </div>
        );
    }
}

export default Home ;