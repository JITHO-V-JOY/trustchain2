import React from 'react';

export default function Loader(){

    return(
        <div style={{textAlign: "center", verticalAlign: "center",  paddingTop: "400px"}}>
        <div className="spinner-border ">

           
        </div>
        <p>please wait...</p>
        </div>
    )
}