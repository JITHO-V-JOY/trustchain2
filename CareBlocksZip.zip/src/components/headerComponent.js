import React, {Component, useState,} from 'react';
import { Switch, Route, Redirect, withRouter, useParams, Router } from 'react-router-dom';
import { connect, useSelector } from 'react-redux';

import {
    Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    NavbarText
  } from 'reactstrap';
import history from './history';
  
 

function  Header(){
    
    const [isOpen, setisOpen] = useState(false)

    const Role = useSelector(state => state.User.role)

    const toggleNav=()=>{
         setisOpen(!isOpen)
    }

        if(Role == 'village-officer'){
            return(
                <Navbar dark expand="md">
                <div className="container">
               <NavbarBrand href="/"><h2>CareBlocks </h2></NavbarBrand>
                   <NavbarToggler onClick={toggleNav} />
                   <Collapse isOpen={isOpen} navbar>
                   <Nav className="mr-auto" navbar>
                   <NavItem>
                                <NavLink onClick={()=> history.push('/home')} >Home</NavLink>              
                                </NavItem>
                                <NavItem>
                                    <NavLink href="/about">
                                    About Us
                                    </NavLink>
                                </NavItem>
                                <NavItem >
                                <NavLink onClick={()=> history.push('/donate')}> Donate</NavLink>

                                </NavItem>
                               
                                
                       <NavItem>
                       <NavLink onClick={()=> history.push('/request')}>Request</NavLink>

                       </NavItem>
                       
                       
                   </Nav>  
                   </Collapse>  
                   </div>
           </Navbar>
            )
        }
        else if(Role == "decision-maker"){
        return(
                    
                    <Navbar dark expand="md">
                         <div className="container">
                        <NavbarBrand href="/"><h2>CareBlocks</h2></NavbarBrand>
                            <NavbarToggler onClick={toggleNav} />
                            <Collapse isOpen={isOpen} navbar>
                            <Nav className="mr-auto" navbar>
                                <NavItem>
                                    <NavLink onClick={()=> history.push('/home')} >Home</NavLink>              
                                </NavItem>
                                <NavItem>
                                <NavLink onClick={()=> history.push('/home')} >About Us</NavLink>              
     
                                </NavItem>
                                <NavItem >
                                <NavLink onClick={()=> history.push('/donate')}> Donate</NavLink>

                                </NavItem>
                                <NavItem>
                                <NavLink onClick={()=> history.push('/validate')}> Validate</NavLink>

                                </NavItem>
                                
                            </Nav>  
                            </Collapse>  
                            </div>
                    </Navbar>
                   
               
        );
    }
    else if(Role == 'user'){
        return(
                    
            <Navbar dark expand="md">
                 <div className="container">
                <NavbarBrand href="/"><h2>CareBlocks</h2></NavbarBrand>
                    <NavbarToggler onClick={toggleNav} />
                    <Collapse isOpen={isOpen} navbar>
                    <Nav className="mr-auto" navbar>
                        <NavItem>
                        <NavLink onClick={()=> history.push('/home')}> Home</NavLink>
                                
                        </NavItem>
                        <NavItem>

                      <NavLink onClick={()=> history.push('/about')}> About Us</NavLink>
 
                        </NavItem>
                        <NavItem>
                      
                                <NavLink onClick={()=> history.push('/donate')}> Donate</NavLink>

                                </NavItem>

                       
                        <NavItem>
                        <NavLink onClick={()=> history.push('/login')}>Login</NavLink>

                        </NavItem>
                    </Nav>  
                    </Collapse>  
                    </div>
            </Navbar>
           
       
);
    }
}



export default Header