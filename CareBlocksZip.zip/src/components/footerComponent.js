import React , {Component} from 'react';


class Footer extends Component{
    render(){
        return(
            <div className="footer">
            <div class="container">
           
            <div className="row row-header">
                <div class="col-sm-12">
                    <h3>Contact Us</h3>
                    <p> careblocks@gmail.com</p>
            </div>
            </div>

            </div>
            </div>
            
        );
    }
}
export default Footer;